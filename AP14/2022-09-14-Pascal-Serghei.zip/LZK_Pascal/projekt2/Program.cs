﻿using System;

namespace projekt2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] Werte = { 2, 1, 4, 3, 5, 3, 2, 1, 3, 4, 5, 4, 2, 3 };
            string ausgabe = "";
            for (int i = 0; i < Werte.Length-1; i++)
            {
                if (Werte[i] < Werte[i+1]) 
                {
                    ausgabe += Werte[i] + ","; 
                }
            }

            Console.WriteLine(ausgabe);
        }
    }
}
