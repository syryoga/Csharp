﻿using System;
using System.Collections.Generic;
using System.Text;

namespace projekt1
{
    class Keil
    {
        //Konstruktor
        public Keil(double a, double b, double c)
        {
            if (a > 0) _Laenge = a;
            if (b > 0) _Breite = b;
            if (c > 0) _HoehenSeite = c;
        }

        //Keil-Länge
        private double _Laenge;

        public double Laenge
        {
            get { return _Laenge; }
            //set { _Laenge = value; }
        }
        private double _Breite;
        //Keil-Breite
        public double Breite
        {
            get { return _Breite; }
            //set { _Breite = value; }
        }
        private double _HoehenSeite;
        //Keil-Höhen Seite
        public double HoehenSeite
        {
            get { return _HoehenSeite; }
            //set { _HoehenSeite = value; }
        }

        //Höhe
        private double HoeheAusrechnen()
        {
            //Formel: Höhe = Math.Sqrt( (4*c*c – b*b) /4)
            double hoehe = Math.Sqrt((4 * HoehenSeite * HoehenSeite - Breite * Breite) / 4);

            //Aufrunden
             hoehe = Math.Round(hoehe, 2);

            return hoehe;

        }
        public double Hoehe
        {
            get { return HoeheAusrechnen(); }
        }


        //Volumen 

        public double Volumen
        {
            get { return GetVolumen(); }
        }

        private double GetVolumen()
        {
            //Formel: Volumen = a * b * h / 2
            double volumen = Laenge * Breite * Hoehe / 2;
            //Aufrunden
            volumen = Math.Round(volumen, 2);

            return volumen;

        }

        //Oberflaeche
        private double GetOberflaeche()
        {
            //Formel: Oberfläche = a*b + 2*a*c + b*h
            double oberflaeche = Laenge * Breite + 2 * Laenge * HoehenSeite + Breite * Hoehe;
            //Aufrunden
            oberflaeche = Math.Round(oberflaeche, 2);

            return oberflaeche;
        }

        public double Oberflaeche
        {
            get { return GetOberflaeche(); }
        }

    }
}
