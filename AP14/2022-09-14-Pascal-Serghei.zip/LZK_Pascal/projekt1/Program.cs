﻿using System;

namespace projekt1
{
    class Program
    {
        static void Main(string[] args)
        {
            Keil k1 = new Keil(8, 3, 5);

            Console.WriteLine("=== Keil Formen ===");
            Console.WriteLine("Volumen = " + k1.Volumen);
            Console.WriteLine("Höhe = " + k1.Hoehe);
            Console.WriteLine("Oberfläche = " + k1.Oberflaeche);
        }
    }
}
