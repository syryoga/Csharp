﻿using System;
using System.Collections.Generic;
using uebung1.Models;
using uebung1.Services;

namespace uebung1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Übung Drucker
            //Eine Klasse mit dem Namen "Drucker" erstellen.
            //Zum Instanziieren muss die Marke und
            //Fachgröße(AnzahlDerMaximalBlaetter) angegeben sein.
            //Der Drucker soll befüllt werden können.

            //Eine Methode "Druck(5)" ist zu realisieren. >> 5 Seiten
            //Alle gedruckten Blätter sollen gezählt werden.
            //also eine Eigenschaft Zähler wird benötigt!
            //die Methode Info() gibt den aktuellen Zustand aus.

            //Beim Starten und Beenden der Anwendung soll der aktuelle Stand gespeichert und geladen werden.

            //Anwendung soll mit einer Menüführung benutzerfreundlicher gemacht werden.

            //Drucker drucker1 = new Drucker("HP", 400);

            //drucker1.Info();



            Drucker drucker = DruckerManager.Laden();

            string eingabe = " ";
            do
            {
                Console.Clear();
                Console.WriteLine("==== DRUCKER ====");
                Console.WriteLine("D: Drucken");
                Console.WriteLine("L: Druckaufträge Löschen");
                Console.WriteLine("B: Befüllen");
                Console.WriteLine("I: Info");
                Console.WriteLine("Q: Beenden");
                Console.WriteLine("----------------------");
                Console.Write("Eingabe: ");
                eingabe = Console.ReadLine().ToUpper();

                switch (eingabe)
                {
                    case "D":
                        Console.Clear();
                        drucker.Druecken();
                        Console.WriteLine("Eingabetaste drücken....");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case "L":
                        Console.Clear();
                        drucker.DruckAuftraegerLoeschen();
                        Console.WriteLine("Druckaufträgen wurden gelöscht\n");
                        Console.WriteLine("Eingabetaste drücken....");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case "B":
                        Console.Clear();
                        Console.Write("Wie viele Seiten wollen sie befühlen ?\n");
                        drucker.Befuehlen(Console.ReadLine());
                        Console.WriteLine("Eingabetaste drücken....");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case "I":
                        drucker.Info();
                        Console.WriteLine("Eingabetaste drücken....");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                    case "Q":
                        DruckerManager.Speichern(drucker);
                        break;

                    default:
                        Console.Clear();
                        Console.WriteLine("Ungültige Eingabe\n");
                        Console.WriteLine("Eingabetaste drücken....");
                        Console.ReadLine();
                        Console.Clear();
                        break;
                }
            } while (eingabe.ToUpper() != "Q");



            Console.WriteLine("\nProgramm wird beendet...");
            // DruckerManager.Speichern(drucker);
        }
    }
}
