﻿using System;
using System.Collections.Generic;
using System.Text;

namespace uebung1.Models
{
    public class Drucker
    {
        // Konstruktor (Leer)
        public Drucker()
        {

        }
        // Konstruktor
        public Drucker(string name, int fachgroesser)
        {
            Name = name;
            Fachgroesser = fachgroesser;
        }


        // Eigenschaften
        private int _Fachgroesser;
        public int Fachgroesser
        {
            get { return _Fachgroesser; }
            private set { if (value > 0 && value < 3000) _Fachgroesser = value; }
        }

        public string Name { get; set; }
        public int Papierfach { get; set; }

        private int Printzeller = 0;

        private int Druckauftraege = 0;






        // Methoden 
        public void Befuehlen(string blaetter)
        {

            if (int.TryParse(blaetter, out int intBlaetter))
            {
                if (intBlaetter > 0)
                {
                    if (Papierfach + intBlaetter <= Fachgroesser)
                    {
                        Console.WriteLine("Drucker wurde mit " + intBlaetter + " befuelt...");
                        Papierfach += intBlaetter;
                        Console.WriteLine("Fachzustand: " + Papierfach);
                    }
                    else
                    {
                        intBlaetter = intBlaetter - (Fachgroesser - Papierfach);
                        Papierfach = Fachgroesser;
                        Console.WriteLine($"Drücker wurde mit {Papierfach} befühlt und sind  {intBlaetter} über geblieben...");
                        Console.WriteLine("Weiter mit 'ENTER'...");
                        Console.ReadLine();
                    }
                }
                else
                {
                    Console.WriteLine("Ungültige eingabe...");
                }
            }
            else
            {
                Console.WriteLine("Ungültige eingabe...");
            }

            // Überprüfen ob noch öffene Druckaufträge sind
            if (Druckauftraege > 0 && Papierfach > 0)
            {
                string auswahl;
                do
                {
                    Console.Clear();
                    Console.WriteLine("Es sind noch Druckaufträge zu drücken...\nWeiter drücken? J(Ja) / N(Nein) ");
                    auswahl = Console.ReadLine().ToUpper();
                    if (auswahl == "J")
                    {
                        if (Papierfach > Druckauftraege)
                        {
                            Console.WriteLine($"{Druckauftraege} Seiten sind ausgedrükt.");
                            Papierfach -= Druckauftraege;
                        }
                        else
                        {
                            Console.WriteLine($"{Papierfach} Seiten von {Druckauftraege} sind ausgedrukt...\nPapierfach ist leer. Bitte nachfülen");
                            Druckauftraege -= Papierfach;
                            Papierfach = 0;
                        }
                    }
                    else if (auswahl == "N")
                    {
                        string antwort;
                        do
                        {
                            Console.WriteLine("Druckaufträge Löschen? J(Ja) / N(Nein)");
                            antwort = Console.ReadLine().ToUpper();

                            if (antwort == "J")
                            {
                                DruckAuftraegerLoeschen();
                            }
                            else if (antwort == "N")
                            {
                                return;
                            }
                        } while (antwort != "J" && antwort != "N");
                    }
                } while (auswahl != "J" && auswahl != "N");
            }
        }





        public void Druecken()
        {
            Console.Write("Wie viele Seiten drücken?");
            string maenge = Console.ReadLine();
            //Überprüfen ob eine Zahl eingegeben ist
            if (int.TryParse(maenge, out int druckmaenge))
            {
                //Überprüfen ob der Zahl grösser als 0 ist
                if (druckmaenge > 0)
                {
                    Druckauftraege += druckmaenge;
                    if (druckmaenge < Papierfach)
                    {
                        Papierfach = Papierfach - druckmaenge;
                        Druckauftraege -= druckmaenge;
                        Console.WriteLine($"Es wurden {druckmaenge} Seiten ausgedrükt.");
                    }
                    else
                    {
                        druckmaenge -= Papierfach;
                        Console.WriteLine($"Es wurden {Papierfach} Seiten von {Papierfach + druckmaenge} ausgedrükt. \nPapierfach ist leer. Bitte nachfülen!");
                        Druckauftraege -= Papierfach;
                        Papierfach = 0;
                    }
                }
                else
                {
                    Console.WriteLine("Ungültige Eingabe...");
                }
            }
            else
            {
                Console.WriteLine("Ungültige Eingabe...");
            }
        }



        public void DruckAuftraegerLoeschen()
        {
            Druckauftraege = 0;
        }



        public void Info()
        {
            Console.Clear();
            Console.WriteLine("----- INFO -----");
            Console.WriteLine("Druckername: " + Name);
            Console.WriteLine("Fachgrößer: " + Fachgroesser);
            Console.WriteLine("Fachzustand: " + Papierfach);
            Console.WriteLine("Gedrükte Seite: " + Printzeller);
            Console.WriteLine("Warteschlange: " + Druckauftraege);
        }
    }
}
