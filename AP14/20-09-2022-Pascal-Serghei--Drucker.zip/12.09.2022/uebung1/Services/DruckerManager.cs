﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.Json;
using uebung1.Models;

namespace uebung1.Services
{
    class DruckerManager
    {
        public static Drucker Laden()
        {
            if (File.Exists("drucker.json"))
            {
                string jsonstring = File.ReadAllText("drucker.json");
                Drucker drucker = JsonSerializer.Deserialize<Drucker>(jsonstring);
                return drucker;
            }
            else
            {
                Drucker drucker = new Drucker("HP", 400);
                return drucker;
            }
        }



        internal static void Speichern(Drucker drucker)
        {
            string jsonString = JsonSerializer.Serialize(drucker);
            File.WriteAllText("drucker.json", jsonString);
        }

        internal static List<Drucker> ImportJSON()
        {
            string inhalt = File.ReadAllText("drucker.json");
            List<Drucker> druckerListe = JsonSerializer.Deserialize<List<Drucker>>(inhalt);
            return druckerListe;
        }
    }
}
